/**
 * 
 */
package bnym.casestudy.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import bnym.casestudy.entity.ContactUs;
import bnym.casestudy.service.formService.ContactUsService;



@Controller
public class ContactController {
	
	@Autowired
	ContactUsService contactUsService;
	
	@RequestMapping("/contactUs")
	public ModelAndView getContactForm(Model model) {
		model.addAttribute("contactForm", new ContactUs());
		ModelAndView mav = new ModelAndView("contactUs");
		return mav;
	}
	
	
	@RequestMapping(value = "/contactUs", method=RequestMethod.POST)
	public ModelAndView submitContactForm(
			@ModelAttribute ("contactForm") ContactUs contactUs,
			BindingResult result) {
		
		
		if(result.hasErrors()) {
			ModelAndView mav = new ModelAndView("contactUs");
			return mav;
		}
		
		contactUsService.saveContactForm(contactUs);
		ModelAndView mav = new ModelAndView("successContact");
		return mav;
	}
	
}
