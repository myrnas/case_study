/**
 * 
 */
package bnym.casestudy.service.clientService;

import java.util.List;

import bnym.casestudy.entity.ClientData;

public interface ClientService {
	
	public List<ClientData> getAllClients();
	public ClientData getClientById(Long id);
	public boolean saveClient(ClientData client);
}
