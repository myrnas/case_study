/**
 * 
 */
package bnym.casestudy.controller;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import bnym.casestudy.entity.Authorities;
import bnym.casestudy.entity.Card;
import bnym.casestudy.entity.ClientData;
import bnym.casestudy.entity.User;
import bnym.casestudy.repository.UserRepository;
import bnym.casestudy.service.clientService.ClientService;






@Controller
@Transactional
public class ClientController {

	@Autowired
	UserRepository userRepository;

	@Autowired
	ClientService clientService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		// binder.setDisallowedFields(new String[] {"sDOB"});
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // 01/01/1980 - 1980-01-01
		binder.registerCustomEditor(Date.class, "dateOfBirth", new CustomDateEditor(sdf, false));
	}

	@RequestMapping("/client/new")
	public ModelAndView getClientForm(Model model, Principal principal, RedirectAttributes redirect) {

		// If you are logged in
		if (principal != null) {
			User user = userRepository.findByUsername(principal.getName());
			ClientData client = user.getClientData();

			// If you are USER but not CLIENT
			if (client == null) {
				model.addAttribute("client", new ClientData());
				ModelAndView mav = new ModelAndView("newMember");
				return mav;
				// If you are USER and CLIENT
			} else {
				ModelAndView mav = new ModelAndView("redirect:/");
				redirect.addFlashAttribute("isClient", "You are already our client!");
				return mav;
			}
			// If you are not logged in
		} else {
			model.addAttribute("user", new User());
			ModelAndView mav = new ModelAndView("newUser");
			return mav;
		}
	}


	@RequestMapping(value = "/client/new", method = RequestMethod.POST)
	public ModelAndView submitClientForm(@ModelAttribute("client") ClientData client, @ModelAttribute("user") User user,
			@RequestParam("confPassword") Optional<String> confPassword, BindingResult result, 
			Principal principal, RedirectAttributes redirect) {

		//If you are not logged in
		if (principal == null) {

			System.out.println(user.toString());
			String username = user.getUsername();
			String emailOfForm = user.getUseremail();
			Boolean userExistsByUsername = userRepository.existsById(username);
			User userExistsByUseremail = userRepository.findByUseremail(emailOfForm);
			
			//If your username or email already in the database
			if (userExistsByUsername || userExistsByUseremail != null) {
				ModelAndView mav = new ModelAndView("newUser");
				mav.addObject("userFound", "Username/Email matches with an existing client! Please login!");
				return mav;
				//If need to open an user account
			} else {
				//If password confirmation passes
				if (user.getPassword().equals(confPassword.get())) {
					
					//If form got validation errors
					if (result.hasErrors()) {
						ModelAndView mav = new ModelAndView("newUser");
						return mav;
					}
					
					//Encrypt password for USER
					String encoded=new BCryptPasswordEncoder().encode(user.getPassword());
					user.setPassword(encoded);
					user.setEnabled(true);
					//Add role to USER
					Authorities role = new Authorities();
					role.setUser(user);
					role.setAuthority("ROLE_USER");
					user.getAuthorities().add(role);
					//Save an USER
					userRepository.save(user);
					ModelAndView mav = new ModelAndView("redirect:/");
					mav.addObject("registrationSuccess", "Registration successful, Please login!");
					return mav;
					//if password confirmation fails
				} else {
					ModelAndView mav = new ModelAndView("newUser");
					mav.addObject("mismatch", "Password did not match, try again!");
					return mav;
				}
			}

			//If USER is looged in
		} else {

			//Set rest of the ClientData
			client.setLegal(true);
			client.setActive(true);	
			
			//Open a Card for ClientData
			Card card = new Card();
			Random rand = new Random();
			String cardNo = String.format((Locale)null, //don't want any thousand separators
			                        "52%02d-%04d-%04d-%04d",
			                        rand.nextInt(100),
			                        rand.nextInt(10000),
			                        rand.nextInt(10000),
			                        rand.nextInt(10000));
			card.setCardNo(cardNo);
			
			 Calendar cal = Calendar.getInstance();
		     Date today = cal.getTime();
		     cal.add(Calendar.YEAR, 5); // to get next 5 year add 5
		     cal.add(Calendar.DAY_OF_MONTH, -1); // to get previous day add -1
		     Date expiryDate = cal.getTime();
		     
			card.setExpiryDate(expiryDate);
			
			
			Long securityCode = (long) (rand.nextInt(900) + 100);
			card.setSecurityCode(securityCode);
			
			//Add Card to ClientData
			client.setCard(card);
			
			//Save ClientData
			clientService.saveClient(client);

			//Set ClientData to the User and save
			User userFound = userRepository.findByUsername(principal.getName());
			userFound.setClientData(client);
			userRepository.save(userFound);

			ModelAndView mav = new ModelAndView("redirect:/");
			redirect.addFlashAttribute("user", user);
			return mav;

		}
	}
	
	
	@RequestMapping(value = "/client/info")
	public ModelAndView getClientInfo(Principal principal, Model model) {
		
				// If logged in as USER
				if (principal != null) {
					User user = userRepository.findByUsername(principal.getName());
					ClientData client = user.getClientData();
					
					//If USER is a CLIENT
					if (client != null) {
						ModelAndView mav = new ModelAndView("home");
						mav.addObject("user", user);						
						return mav;
					
						//If USER is not a CLIENT
					} else {
						model.addAttribute("client", new ClientData());
						ModelAndView mav = new ModelAndView("newMember");
						return mav;
						
					}

					//If not logged in
				} else {
					model.addAttribute("user", new User());
					ModelAndView mav = new ModelAndView("newUser");
					return mav;
				}
	}
	
}
