/**
 * 
 */
package bnym.casestudy.service.formService;

import java.util.List;

import bnym.casestudy.entity.ContactUs;


public interface ContactUsService {
	
	public List<ContactUs> getAllContactForms();
	public ContactUs getContactById(Long id);
	public boolean saveContactForm(ContactUs contactUs);
}
