/**
 * 
 */
package bnym.casestudy.service.loginService;
import bnym.casestudy.entity.User;


public interface UserDetailsDao{
	User findUserByUsername(String username);
}
