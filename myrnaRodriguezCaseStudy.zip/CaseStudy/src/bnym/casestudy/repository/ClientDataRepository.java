/**
 * 
 */
package bnym.casestudy.repository;

import org.springframework.data.repository.CrudRepository;

import bnym.casestudy.entity.ClientData;
 


public interface ClientDataRepository extends CrudRepository<ClientData, Long>{

}
