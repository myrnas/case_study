package bnym.casestudy.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import bnym.casestudy.entity.ClientData;
import bnym.casestudy.entity.User;
import bnym.casestudy.repository.UserRepository;

@Controller
public class IndexController {
	
	
	@Autowired
	UserRepository userRepository;

		@RequestMapping("/")
		public ModelAndView getHomePage(Model model, Principal principal) {
			
			String username = principal.getName();
			System.out.println("Logged in username: "+username);
			User user = userRepository.findByUsername(username);
			System.out.println("Logged in user clientID: "+user.getUseremail());
			
			ClientData client = user.getClientData();

			//If USER is not a CLIENT
			if(client == null) {
				ModelAndView mav = new ModelAndView("home");
				mav.addObject("member", "You are not a client yet, please fill the membership form!");
				mav.addObject("beClient", "<a href=\"client/new\">Apply!</a>");
				mav.addObject("user", user);
				return mav;
				//If USER is a CLIENT
			}else {
				ModelAndView mav = new ModelAndView("home");
				mav.addObject("member", "Welcome back!");
				mav.addObject("user", user);
				return mav;
			}
			
			
		}
		
		
		@RequestMapping("/admin/report")
		public ModelAndView getAdminReport(Model model, Principal principal) {
			ModelAndView mav = new ModelAndView("adminReport");
			return mav;
		}
}
