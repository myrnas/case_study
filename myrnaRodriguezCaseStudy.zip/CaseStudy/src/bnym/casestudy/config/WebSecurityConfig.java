package bnym.casestudy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@ComponentScan("bnym.casestudy")
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  @Autowired
  private UserDetailsService userDetailsService;
  
  @Bean
  public BCryptPasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }
  
  @Bean
  public UserDetailsService userDetailsServiceBean() throws Exception {
      return super.userDetailsServiceBean();
  }
  
  
  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
  }

  // fix this
  @Override
  public void configure(WebSecurity web) throws Exception {
  web
     .ignoring()
     .antMatchers("/js/**", "/images/**","/css/**", "/resource/**", "/scripts/**");
  }

  // fix this
  // "/js/**", "/images/**","/css/**", "/resource/**", "/scripts/**"
  
  @Override
  protected void configure(HttpSecurity http) throws Exception {
     http
             .authorizeRequests()
             .antMatchers("/contactUs", "/client/new").permitAll()
             .antMatchers("/client/**").hasRole("USER")
             .antMatchers("/admin/**").hasRole("ADMIN")
             .antMatchers("/all/**").hasAnyRole("ADMIN","USER")
             .anyRequest().authenticated()
     	    .and()
             .formLogin()
                 .loginPage("/login").loginProcessingUrl("/j_spring_security_check")
                 .defaultSuccessUrl("/", true)
                 .permitAll()
                 .and()
                 .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
         	    .and()
         	    .csrf().disable();
 }
}
