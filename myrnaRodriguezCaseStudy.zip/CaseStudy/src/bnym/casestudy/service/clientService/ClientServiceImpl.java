/**
 * 
 */
package bnym.casestudy.service.clientService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bnym.casestudy.entity.ClientData;

import bnym.casestudy.repository.ClientDataRepository;


@Service
@Transactional
public class ClientServiceImpl implements ClientService{
	
	@Autowired
	ClientDataRepository repository;

	@Override
	public List<ClientData> getAllClients() {
		List<ClientData> list = new ArrayList<ClientData>();
		for (ClientData client : repository.findAll()) {
			list.add(client);
		}
		return list;
	}


	@Override
	public ClientData getClientById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean saveClient(ClientData client) {
		try {
			repository.save(client);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
