/**
 * 
 */
package bnym.casestudy.service.formService;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bnym.casestudy.entity.ContactUs;
import bnym.casestudy.repository.ContactUsRepository;



@Service
@Transactional
public class ContactUsServiceImpl implements ContactUsService{
	
	
	@Autowired
	ContactUsRepository repository;
	

	@Override
	public List<ContactUs> getAllContactForms() {
		List<ContactUs> list = new ArrayList<ContactUs>();
		for (ContactUs contactUs : repository.findAll()) {
			list.add(contactUs);
		}
		return list;
	}


	@Override
	public ContactUs getContactById(Long id) {
		ContactUs contactUs = repository.findById(id).get();
		return contactUs;
	}

	
	@Override
	public boolean saveContactForm(ContactUs contactUs) {
		try {
			repository.save(contactUs);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
