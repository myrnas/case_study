package bnym.casestudy.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
		private Long id;
	
			
		@NotBlank (message="Can not be Empty")
		private String street_name;
		
		@NotBlank (message="Can not be Empty")
		private String client_city;
		
		@NotBlank (message="Enter 2-letter state code") 
		@Size(max=2)
		 @Pattern(regexp="[A-Z]{2}")
		private String client_state;
		
		private String client_country;
		
		@NotBlank (message="Enter 5-digit zip-code")
		 @Size(max=5)  
		@Pattern(regexp="\\d{5}")
		private String client_zip;

		
		public Long getId() {
			
			return id;
		}
		
		
		public void setId(Long id) {
			this.id = id;
		}
	 
	 
		 
		public String getStreet_name() {
			return street_name;
		}
		public void setStreet_name(String street_name) {
			this.street_name = street_name;
		}
		public String getClient_city() {
			return client_city;
		}
		public void setClient_city(String client_city) {
			this.client_city = client_city;
		}
		 
		 public String getClient_state() {
			return client_state;
		}
		public void setClient_state(String client_state) {
			this.client_state = client_state;
		}
		
		public String getClient_country() {
			return client_country;
		}
		public void setClient_country(String client_country) {
			this.client_country = client_country;
		}
		
		
		public String getClient_zip() {
			return client_zip;
		}
		public void setClient_zip(String client_zip) {
			this.client_zip = client_zip;
		}

	}





